package com.realmforge.v2;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.network.packet.CustomPayload;
import java.lang.reflect.Field;
import java.util.*;

/** Single-page RealmForge book. Trait and Perk lookup buttons are on Informations. */
public final class RealmForgeBookScreen extends Screen {
    private enum Page { STATUS, INFORMATION, TRAITS, PERKS }
    private final Page page;
    private static int traitOffset = 0;
    private static final int PAPER = 0xFFF0E1B8;
    private static final int INK = 0xFF342719;
    private static final List<Perk> PERKS = List.of(
        new Perk("Iron Will", "COMMON", "Take 5% less damage", 30),
        new Perk("Swift Step", "COMMON", "+4% movement speed", 25),
        new Perk("Keen Mind", "UNCOMMON", "+8% EXP gained", 18),
        new Perk("Vital Core", "UNCOMMON", "+10% maximum HP", 12),
        new Perk("Battle Focus", "RARE", "+8% attack damage", 8),
        new Perk("Energy Well", "EPIC", "+15% maximum Energy", 4),
        new Perk("Fortune Soul", "LEGENDARY", "+12% luck", 2),
        new Perk("Worldbreaker", "MYTHIC", "+20% skill damage", 1)
    );
    private record Perk(String name, String rarity, String buff, int chance) {}

    public RealmForgeBookScreen() { this(Page.STATUS); }
    private RealmForgeBookScreen(Page page) {
        super(Text.literal("RealmForge Book"));
        this.page = page;
    }

    @Override protected void init() {
        int bookW = Math.min(330, this.width - 16);
        int x = (this.width - bookW) / 2;
        int bookH = Math.min(310, this.height - 54);
        int y = Math.max(8, (this.height - bookH - 28) / 2);
        int buttonY = Math.min(this.height - 22, y + bookH + 5);
        int gap = 4;
        int buttonW = Math.max(52, (bookW - 3 * gap) / 4);
        addPageButton("Status", Page.STATUS, x, buttonY, buttonW);
        addPageButton("Informations", Page.INFORMATION, x + buttonW + gap, buttonY, buttonW);
        addDrawableChild(ButtonWidget.builder(Text.literal(page == Page.STATUS || page == Page.INFORMATION ? "Close" : "Back"), b -> {
            if (this.client != null) this.client.setScreen(page == Page.STATUS || page == Page.INFORMATION ? null : new RealmForgeBookScreen(Page.INFORMATION));
        }).dimensions(x + 2 * (buttonW + gap), buttonY, buttonW, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Exit"), b -> { if (this.client != null) this.client.setScreen(null); })
            .dimensions(x + 3 * (buttonW + gap), buttonY, buttonW, 20).build());

        if (page == Page.STATUS) {
            int statY = y + 185;
            String[] stats = {"Vitality", "Strength", "Agility", "Intelligence", "Energy", "Defense", "Luck"};
            for (int i = 0; i < stats.length; i++) {
                final int index = i;
                addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> spendPoint(index))
                    .dimensions(x + bookW - 35, statY + i * 15, 20, 14).build());
            }
        }
        if (page == Page.INFORMATION) {
            addDrawableChild(ButtonWidget.builder(Text.literal("Trait [?]"), b -> this.client.setScreen(new RealmForgeBookScreen(Page.TRAITS)))
                .dimensions(x + 12, y + 122, bookW - 24, 22).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Perk [?]"), b -> this.client.setScreen(new RealmForgeBookScreen(Page.PERKS)))
                .dimensions(x + 12, y + 153, bookW - 24, 22).build());
        }
    }

    private void addPageButton(String label, Page target, int x, int y, int w) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> { if (this.client != null) this.client.setScreen(new RealmForgeBookScreen(target)); })
            .dimensions(x, y, w, 20).build());
    }

    private void spendPoint(int statIndex) {
        try {
            Class<?> payloadClass = Class.forName("com.realmforge.network.SpendPointPayload");
            Object payload = payloadClass.getConstructor(int.class).newInstance(statIndex);
            ClientPlayNetworking.send((CustomPayload) payload);
        } catch (Throwable ignored) {
            if (client != null && client.player != null) client.player.sendMessage(Text.literal("Could not send stat request to server."), true);
        }
    }

    @Override public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xFF17131D); // no blur
        ctx.fill(0, 0, width, 4, 0xFF7E55C7);
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        int bookW = Math.min(330, width - 16);
        int bookH = Math.min(310, height - 54);
        int x = (width - bookW) / 2;
        int y = Math.max(8, (height - bookH - 28) / 2);
        ctx.fill(x - 3, y - 3, x + bookW + 3, y + bookH + 3, 0xFF5D351D);
        ctx.fill(x, y, x + bookW, y + bookH, PAPER);
        ctx.fill(x, y, x + bookW, y + 3, 0xFFB99A65);
        ctx.drawTextWithShadow(textRenderer, Text.literal("REALMFORGE").formatted(Formatting.GOLD, Formatting.BOLD), x + 12, y + 10, INK);
        ctx.fill(x + 10, y + 25, x + bookW - 10, y + 26, 0xFFB99A65);
        switch (page) {
            case STATUS -> drawStatus(ctx, x, y, bookW, bookH);
            case INFORMATION -> drawInfo(ctx, x, y, bookW, bookH);
            case TRAITS -> drawTraits(ctx, x, y, bookW, bookH);
            case PERKS -> drawPerks(ctx, x, y, bookW, bookH);
        }
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawStatus(DrawContext c, int x, int y, int w, int h) {
        int level = number("level", 1), xp = number("xp", 0), xpNeed = Math.max(1, number("xpNeeded", 100));
        int energy = number("energy", 3), maxEnergy = Math.max(1, number("maxEnergy", 3));
        String name = client != null && client.player != null ? client.player.getName().getString() : "Player";
        int hp = client != null && client.player != null ? (int) client.player.getHealth() : 20;
        int hpMax = client != null && client.player != null ? (int) client.player.getMaxHealth() : 20;
        c.drawTextWithShadow(textRenderer, Text.literal(name).formatted(Formatting.AQUA, Formatting.BOLD), x + 12, y + 34, INK);
        c.drawTextWithShadow(textRenderer, Text.literal("Rank: " + rankName(level)).formatted(Formatting.GOLD, Formatting.BOLD), x + 12, y + 49, INK);
        c.drawTextWithShadow(textRenderer, Text.literal("Level " + level + "  •  Points: " + number("points", 0)), x + 12, y + 64, INK);
        bar(c, x + 12, y + 84, w - 24, "HP", hp, hpMax, 0xFFCC3E50);
        bar(c, x + 12, y + 112, w - 24, "EXP", xp, xpNeed, 0xFF5E9BEB);
        bar(c, x + 12, y + 140, w - 24, "Energy", energy, maxEnergy, 0xFF44BFA3);
        c.drawTextWithShadow(textRenderer, Text.literal("ATTRIBUTES").formatted(Formatting.DARK_BLUE, Formatting.BOLD), x + 12, y + 170, INK);
        String[] names = {"Vitality", "Strength", "Agility", "Intelligence", "Energy", "Defense", "Luck"};
        int[] stats = statValues();
        for (int i = 0; i < names.length; i++) {
            int yy = y + 187 + i * 15;
            c.drawTextWithShadow(textRenderer, Text.literal(names[i] + ": " + (i < stats.length ? stats[i] : 0)), x + 12, yy, INK);
        }
        c.drawTextWithShadow(textRenderer, Text.literal("Use Informations for Trait [?] and Perk [?].").formatted(Formatting.DARK_PURPLE), x + 12, y + h - 17, INK);
    }

    private void drawInfo(DrawContext c, int x, int y, int w, int h) {
        c.drawTextWithShadow(textRenderer, Text.literal("INFORMATIONS").formatted(Formatting.DARK_PURPLE, Formatting.BOLD), x + 12, y + 35, INK);
        String[] lines = {"• Press M to open the book", "• Spend stat points on Status", "• HP, EXP and Energy show progress", "• Trait and Perk stay permanent", "• No races or rerolls"};
        int yy = y + 53;
        for (String line : lines) { c.drawTextWithShadow(textRenderer, Text.literal(line), x + 12, yy, INK); yy += 15; }
        c.drawTextWithShadow(textRenderer, Text.literal("DETAILS — tap a button:").formatted(Formatting.GOLD, Formatting.BOLD), x + 12, y + 105, INK);
        c.drawTextWithShadow(textRenderer, Text.literal("View all entries, rarities, buffs and chances."), x + 12, y + 181, INK);
    }

    private void drawTraits(DrawContext c, int x, int y, int w, int h) {
        c.drawTextWithShadow(textRenderer, Text.literal("TRAITS — RARITY & BONUSES").formatted(Formatting.DARK_PURPLE, Formatting.BOLD), x + 12, y + 35, INK);
        c.drawTextWithShadow(textRenderer, Text.literal("Selected: " + string("trait", "Unassigned")).formatted(Formatting.BLUE), x + 12, y + 50, INK);
        List<String> traits = existingTraits();
        int visible = Math.max(1, (h - 92) / 30);
        traitOffset = Math.max(0, Math.min(traitOffset, Math.max(0, traits.size() - visible)));
        for (int i = 0; i < visible && traitOffset + i < traits.size(); i++) {
            String[] p = traits.get(traitOffset + i).split("\\|", 4);
            int yy = y + 68 + i * 30;
            String heading = p.length > 2 ? p[0] + " — " + p[1] + " " + p[2] : traits.get(traitOffset + i);
            c.drawTextWithShadow(textRenderer, Text.literal(heading).formatted(Formatting.DARK_PURPLE), x + 12, yy, INK);
            if (p.length > 3) c.drawTextWithShadow(textRenderer, Text.literal(p[3].length() > 40 ? p[3].substring(0, 37) + "..." : p[3]), x + 12, yy + 12, INK);
        }
        c.drawTextWithShadow(textRenderer, Text.literal("Scroll to browse • permanent selection"), x + 12, y + h - 17, INK);
    }

    private void drawPerks(DrawContext c, int x, int y, int w, int h) {
        Perk selected = selectedPerk();
        c.drawTextWithShadow(textRenderer, Text.literal("YOUR PERMANENT PERK").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD), x + 12, y + 35, INK);
        c.drawTextWithShadow(textRenderer, Text.literal(selected.name + " — " + selected.rarity).formatted(Formatting.GOLD, Formatting.BOLD), x + 12, y + 52, INK);
        c.drawTextWithShadow(textRenderer, Text.literal(selected.buff), x + 12, y + 67, INK);
        c.drawTextWithShadow(textRenderer, Text.literal("AVAILABLE PERKS / CHANCES").formatted(Formatting.DARK_BLUE, Formatting.BOLD), x + 12, y + 91, INK);
        int row = 0;
        for (Perk p : PERKS) {
            if (y + 111 + row * 20 > y + h - 15) break;
            c.drawTextWithShadow(textRenderer, Text.literal(p.name + " (" + p.rarity + ") — " + p.chance + "%"), x + 12, y + 111 + row * 20, INK);
            row++;
        }
    }

    private void bar(DrawContext c, int x, int y, int w, String label, int value, int max, int color) {
        c.drawTextWithShadow(textRenderer, Text.literal(label + "  " + value + "/" + max), x, y, INK);
        int by = y + 11;
        c.fill(x, by, x + w, by + 7, 0xFF5A5148);
        int fill = (int)(w * Math.max(0, Math.min(1, value / (float)Math.max(1, max))));
        c.fill(x, by, x + fill, by + 7, color);
    }
    private int number(String field, int fallback) {
        try { Class<?> c = Class.forName("com.realmforge.client.ClientRPGData"); Field f = c.getField(field); return f.getInt(null); }
        catch (Throwable ignored) { return fallback; }
    }
    private String string(String field, String fallback) {
        try { Object v = Class.forName("com.realmforge.client.ClientRPGData").getField(field).get(null); return v == null ? fallback : v.toString(); }
        catch (Throwable ignored) { return fallback; }
    }
    private int[] statValues() {
        try { Object a = Class.forName("com.realmforge.client.ClientRPGData").getField("stats").get(null); return (int[]) a; }
        catch (Throwable ignored) { return new int[7]; }
    }
    private String rankName(int level) {
        try { Class<?> rm = Class.forName("com.realmforge.progression.RankManager"); Object rank = rm.getMethod("forLevel", int.class).invoke(null, level); return String.valueOf(rank.getClass().getField("displayName").get(rank)); }
        catch (Throwable ignored) { return "Awakening"; }
    }
    private List<String> existingTraits() {
        List<String> out = new ArrayList<>();
        try {
            Class<?> registry = Class.forName("com.realmforge.registry.TraitRegistry"); Object result = registry.getMethod("all").invoke(null);
            if (result instanceof Collection<?> all) {
                List<Object> entries = new ArrayList<>(all); double total = 0;
                for (Object t : entries) { Object r = t.getClass().getMethod("rarity").invoke(t); try { total += r.getClass().getField("weight").getDouble(r); } catch (Throwable ignored) { total += 1; } }
                for (Object t : entries) {
                    String name = String.valueOf(t.getClass().getMethod("name").invoke(t)); Object r = t.getClass().getMethod("rarity").invoke(t); String rarity = String.valueOf(r); double weight = 1;
                    try { weight = r.getClass().getField("weight").getDouble(r); } catch (Throwable ignored) {}
                    String chance = String.format(Locale.ROOT, "%.1f%%", total <= 0 ? 0 : 100 * weight / total); Object bonuses = t.getClass().getMethod("bonuses").invoke(t);
                    out.add(name + "|" + rarity + " " + chance + "|" + chance + "|" + bonuses);
                }
            }
        } catch (Throwable ignored) { out.add("Trait registry|UNKNOWN|0%|Registry unavailable"); }
        return out;
    }
    private Perk selectedPerk() {
        UUID id = client != null && client.player != null ? client.player.getUuid() : new UUID(0, 0);
        int roll = Math.floorMod((int)(id.getMostSignificantBits() ^ id.getLeastSignificantBits()), 100) + 1;
        int total = 0; for (Perk p : PERKS) { total += p.chance; if (roll <= total) return p; }
        return PERKS.get(0);
    }
    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (page == Page.TRAITS) { traitOffset = Math.max(0, traitOffset + (verticalAmount < 0 ? 1 : -1)); return true; }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }
    @Override public boolean shouldPause() { return false; }
}
