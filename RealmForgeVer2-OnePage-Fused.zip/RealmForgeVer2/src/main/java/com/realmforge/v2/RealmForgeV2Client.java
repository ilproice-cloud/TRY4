package com.realmforge.v2;

import net.fabricmc.api.ClientModInitializer;

public final class RealmForgeV2Client implements ClientModInitializer {
    @Override public void onInitializeClient() {
        // The mixin replaces the original RealmForge stats screen with RealmForgeBookScreen.
    }
}
