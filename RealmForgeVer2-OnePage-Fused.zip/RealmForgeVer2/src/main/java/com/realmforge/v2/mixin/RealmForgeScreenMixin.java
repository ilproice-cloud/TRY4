package com.realmforge.v2.mixin;

import com.realmforge.v2.RealmForgeBookScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(MinecraftClient.class)
public abstract class RealmForgeScreenMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen realmforge$replaceStatsBook(Screen incoming) {
        if (incoming != null && incoming.getClass().getName().equals("com.realmforge.screen.RPGScreen")) {
            return new RealmForgeBookScreen();
        }
        return incoming;
    }
}
