package com.realmforge.v2;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.network.ServerPlayerEntity;

/** Ensures new characters begin with three Energy, without overwriting established characters. */
public final class RealmForgeV2Init implements ModInitializer {
    @Override public void onInitialize() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.player;
            try {
                Class<?> dataClass = Class.forName("com.realmforge.player.RPGPlayerData");
                Object data = dataClass.getMethod("get", ServerPlayerEntity.class).invoke(null, player);
                java.lang.reflect.Field levelField = dataClass.getField("level");
                java.lang.reflect.Field energyField = dataClass.getField("energy");
                java.lang.reflect.Field traitField = dataClass.getField("trait");
                int level = levelField.getInt(data);
                if (level <= 1 && energyField.getInt(data) == 0) {
                    energyField.setInt(data, 3);
                    dataClass.getMethod("save", ServerPlayerEntity.class).invoke(data, player);
                }
                // Trait is left to the existing server-side trait system; never reroll it here.
                if (traitField.get(data) == null) {
                    // Intentionally do not replace the trait from this compatibility layer.
                }
            } catch (Throwable ignored) {
                // Preserve normal game startup if the original mod's internals differ.
            }
        });
    }
}
