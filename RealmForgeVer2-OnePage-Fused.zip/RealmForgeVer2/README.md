# RealmForgeVer2

This project is intended as one Fabric 1.21.1 mod built by merging the original RealmForge JAR contents with the RealmForgeVer2 UI overlay. The book UI is a **single-page book**. The **Informations** page contains the **Trait [?]** and **Perk [?]** buttons; those open their own detail pages.

Build on GitHub Actions with Java 21 and Gradle. The build has not been validated in a live Minecraft/PojavLauncher session.
