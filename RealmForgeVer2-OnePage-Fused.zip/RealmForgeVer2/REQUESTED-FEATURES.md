# RealmForgeVer2 feature implementation notes

Implemented in the added Java source layer (build still needs verification by GitHub Actions):

- Opaque two-page book screen replacing the original stats screen; no vanilla blur.
- Player name, rank, level, stat points, HP/EXP/Energy bars with current/max values.
- Informations page.
- Trait and Perk detail pages reached from the status page's Trait [?] and Perk [?] buttons, with a Back button.
- Trait list reads the existing registry and includes rarity, bonuses, and approximate weighted chance; scroll to browse the list.
- Permanent UUID-stable perk selection with rarity, bonus, and chance list.
- Attribute plus buttons send stat-spend payloads to the existing server handler.
- Level-1 characters with zero Energy are initialized to 3 Energy.
- No race or character-creation flow is added.

The original RealmForge classes are packaged from the supplied JAR. The added source layer has not been compiled in this environment because Gradle/Fabric dependencies cannot be run here. Use the included GitHub Actions workflow to compile, then share any build log errors for correction.
