package com.realmforge.v2;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.network.packet.CustomPayload;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

/** Two-page, opaque stats book layered over RealmForge's existing screen. */
public final class RealmForgeBookScreen extends Screen {
    private enum Page { STATUS, INFORMATION, TRAITS, PERKS }
    private final Page page;
    private static int listOffset = 0;
    private static final int PAPER = 0xFFF0E1B8;
    private static final int INK = 0xFF342719;
    private static final int GOLD = 0xFFFFD34E;
    private static final List<Perk> PERKS = List.of(
        new Perk("Iron Will", "COMMON", "Take 5% less damage", 30),
        new Perk("Swift Step", "COMMON", "+4% movement speed", 25),
        new Perk("Keen Mind", "UNCOMMON", "+8% EXP gained", 18),
        new Perk("Vital Core", "UNCOMMON", "+10% maximum HP", 12),
        new Perk("Battle Focus", "RARE", "+8% attack damage", 8),
        new Perk("Energy Well", "EPIC", "+15% maximum Energy", 4),
        new Perk("Fortune Soul", "LEGENDARY", "+12% luck", 2),
        new Perk("Worldbreaker", "MYTHIC", "+20% skill damage", 1)
    );

    private record Perk(String name, String rarity, String buff, int chance) {}

    public RealmForgeBookScreen() { this(Page.STATUS); }
    private RealmForgeBookScreen(Page page) {
        super(Text.literal("RealmForge — Status Book"));
        this.page = page;
    }

    @Override
    protected void init() {
        int bookW = Math.min(520, this.width - 16);
        int left = (this.width - bookW) / 2;
        int y = Math.min(this.height - 24, this.height / 2 + 111);
        int gap = 4;
        int buttonW = Math.max(52, (bookW - 4 * gap) / 4);
        addButton("Status", Page.STATUS, left, y, buttonW);
        addButton("Informations", Page.INFORMATION, left + buttonW + gap, y, buttonW);
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> {
            if (this.client != null) this.client.setScreen(new RealmForgeBookScreen(Page.STATUS));
        }).dimensions(left + 2 * (buttonW + gap), y, buttonW, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> {
            if (this.client != null) this.client.setScreen(null);
        }).dimensions(left + 3 * (buttonW + gap), y, buttonW, 20).build());
        if (page == Page.STATUS) {
            int bookY = Math.max(8, (this.height - Math.min(252, this.height - 48) - 28) / 2);
            int half = bookW / 2;
            addDrawableChild(ButtonWidget.builder(Text.literal("Trait [?]"), b -> this.client.setScreen(new RealmForgeBookScreen(Page.TRAITS)))
                .dimensions(left + 10, bookY + 158, Math.max(58, half / 3), 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Perk [?]"), b -> this.client.setScreen(new RealmForgeBookScreen(Page.PERKS)))
                .dimensions(left + 10 + Math.max(58, half / 3) + 4, bookY + 158, Math.max(58, half / 3), 18).build());
            String[] stats = {"Vitality", "Strength", "Agility", "Intelligence", "Energy", "Defense", "Luck"};
            for (int i = 0; i < stats.length; i++) {
                final int statIndex = i;
                addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> spendPoint(statIndex))
                    .dimensions(left + bookW - 34, bookY + 42 + i * 19, 18, 17).build());
            }
        }
    }

    private void spendPoint(int statIndex) {
        try {
            Class<?> payloadClass = Class.forName("com.realmforge.network.SpendPointPayload");
            Object payload = payloadClass.getConstructor(int.class).newInstance(statIndex);
            ClientPlayNetworking.send((CustomPayload) payload);
        } catch (Throwable ignored) {
            if (client != null && client.player != null) client.player.sendMessage(Text.literal("Could not send stat request to server."), true);
        }
    }

    private void addButton(String label, Page target, int x, int y, int w) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> {
            if (this.client != null) this.client.setScreen(new RealmForgeBookScreen(target));
        }).dimensions(x, y, w, 20).build());
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Deliberately draw an opaque background instead of the vanilla blurred panorama.
        ctx.fill(0, 0, width, height, 0xFF17131D);
        ctx.fill(0, 0, width, 4, 0xFF7E55C7);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        int bookW = Math.min(520, width - 16);
        int bookH = Math.min(252, height - 48);
        int x = (width - bookW) / 2;
        int y = Math.max(8, (height - bookH - 28) / 2);
        int half = bookW / 2;
        ctx.fill(x - 3, y - 3, x + bookW + 3, y + bookH + 3, 0xFF5D351D);
        ctx.fill(x, y, x + half - 2, y + bookH, PAPER);
        ctx.fill(x + half + 2, y, x + bookW, y + bookH, PAPER);
        ctx.fill(x + half - 2, y, x + half + 2, y + bookH, 0xFFB99A65);
        ctx.drawTextWithShadow(textRenderer, Text.literal("REALMFORGE").formatted(Formatting.GOLD, Formatting.BOLD), x + 12, y + 9, INK);
        ctx.drawTextWithShadow(textRenderer, Text.literal("STATUS GRIMOIRE").formatted(Formatting.DARK_PURPLE), x + half + 12, y + 9, INK);
        switch (page) {
            case STATUS -> drawStatus(ctx, x, y, half, bookH);
            case INFORMATION -> drawInfo(ctx, x, y, half, bookH);
            case TRAITS -> drawTraits(ctx, x, y, half, bookH);
            case PERKS -> drawPerks(ctx, x, y, half, bookH);
        }
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawStatus(DrawContext c, int x, int y, int half, int h) {
        int level = number("level", 1), xp = number("xp", 0), xpNeed = Math.max(1, number("xpNeeded", 100));
        int energy = number("energy", 3), maxEnergy = Math.max(1, number("maxEnergy", 3));
        String name = client != null && client.player != null ? client.player.getName().getString() : "Player";
        String rank = rankName(level);
        c.drawTextWithShadow(textRenderer, Text.literal(name).formatted(Formatting.AQUA, Formatting.BOLD), x + 12, y + 28, INK);
        c.drawTextWithShadow(textRenderer, Text.literal("Rank: " + rank).formatted(Formatting.GOLD, Formatting.BOLD), x + 12, y + 42, INK);
        c.drawTextWithShadow(textRenderer, Text.literal("Level " + level + "   Points: " + number("points", 0)), x + 12, y + 58, INK);
        int hp = client != null && client.player != null ? (int) client.player.getHealth() : 20;
        int hpMax = client != null && client.player != null ? (int) client.player.getMaxHealth() : 20;
        bar(c, x + 12, y + 78, half - 28, "HP", hp, hpMax, 0xFFCC3E50);
        bar(c, x + 12, y + 104, half - 28, "EXP", xp, xpNeed, 0xFF5E9BEB);
        bar(c, x + 12, y + 130, half - 28, "Energy", energy, maxEnergy, 0xFF44BFA3);
        c.drawTextWithShadow(textRenderer, Text.literal("Trait [?]" ).formatted(Formatting.DARK_PURPLE, Formatting.BOLD), x + 12, y + 163, INK);
        c.drawTextWithShadow(textRenderer, Text.literal("Perk [?]").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD), x + 12, y + 181, INK);
        c.drawTextWithShadow(textRenderer, Text.literal("Tap Traits / Perks below for details."), x + 12, y + h - 18, INK);

        int rx = x + half + 12;
        c.drawTextWithShadow(textRenderer, Text.literal("ATTRIBUTES").formatted(Formatting.DARK_BLUE, Formatting.BOLD), rx, y + 29, INK);
        String[] names = {"Vitality", "Strength", "Agility", "Intelligence", "Energy", "Defense", "Luck"};
        int[] stats = statValues();
        for (int i = 0; i < names.length; i++) {
            int yy = y + 47 + i * 19;
            c.drawTextWithShadow(textRenderer, Text.literal(names[i] + ": " + (i < stats.length ? stats[i] : 0)), rx, yy, INK);
            int bx = x + bookWSafe(half) - 42;
            if (number("points", 0) > 0) {
                // Small plus affordance is an actual network action to the existing server handler.
                c.drawTextWithShadow(textRenderer, Text.literal("[+]" ).formatted(Formatting.GREEN, Formatting.BOLD), bx, yy, INK);
            }
        }
        c.drawTextWithShadow(textRenderer, Text.literal("Progress is synced from the server."), rx, y + h - 18, INK);
    }

    private int bookWSafe(int half) { return half * 2; }

    private void drawInfo(DrawContext c, int x, int y, int half, int h) {
        String[] left = {"INFORMATIONS", "• Press M to open the book", "• Spend points with [+]", "• HP is your current health", "• EXP fills toward the next level", "• Energy is used by abilities", "", "Trait and Perk are permanent.", "Races / character creation are", "not part of this updated system."};
        for (int i = 0; i < left.length; i++) c.drawTextWithShadow(textRenderer, Text.literal(left[i]).formatted(i == 0 ? Formatting.DARK_PURPLE : Formatting.BLACK), x + 12, y + 30 + i * 17, INK);
        String[] right = {"RARITY GUIDE", "Common — frequent", "Uncommon — less frequent", "Rare — uncommon reward", "Epic — powerful reward", "Legendary — very rare", "Mythic — extremely rare", "", "Each player keeps one Trait", "and one Perk; no rerolls."};
        for (int i = 0; i < right.length; i++) c.drawTextWithShadow(textRenderer, Text.literal(right[i]).formatted(i == 0 ? Formatting.GOLD : Formatting.BLACK), x + half + 12, y + 30 + i * 17, INK);
    }

    private void drawTraits(DrawContext c, int x, int y, int half, int h) {
        c.drawTextWithShadow(textRenderer, Text.literal("YOUR PERMANENT TRAIT").formatted(Formatting.DARK_PURPLE, Formatting.BOLD), x + 12, y + 29, INK);
        String current = string("trait", "Unassigned");
        c.drawTextWithShadow(textRenderer, Text.literal("Selected: " + current).formatted(Formatting.BLUE), x + 12, y + 43, INK);
        List<String> traits = existingTraits();
        int visible = 5;
        int maxOffset = Math.max(0, (traits.size() + 1) / 2 - visible);
        listOffset = Math.max(0, Math.min(listOffset, maxOffset));
        for (int col = 0; col < 2; col++) {
            int startIndex = listOffset + col * visible;
            for (int row = 0; row < visible; row++) {
                int index = startIndex + row;
                if (index >= traits.size()) break;
                String[] parts = traits.get(index).split("\\|", 4);
                int tx = x + (col == 0 ? 12 : half + 12);
                int ty = y + 63 + row * 35;
                String heading = parts.length > 2 ? parts[0] + " — " + parts[1] + " " + parts[2] : traits.get(index);
                String bonus = parts.length > 3 ? parts[3] : "";
                c.drawTextWithShadow(textRenderer, Text.literal(heading).formatted(Formatting.DARK_PURPLE), tx, ty, INK);
                c.drawTextWithShadow(textRenderer, Text.literal(bonus.length() > 34 ? bonus.substring(0, 31) + "..." : bonus), tx, ty + 12, INK);
            }
        }
        c.drawTextWithShadow(textRenderer, Text.literal("Scroll to view all traits  •  No rerolls"), x + 12, y + h - 17, INK);
    }

    private void drawPerks(DrawContext c, int x, int y, int half, int h) {
        Perk selected = selectedPerk();
        c.drawTextWithShadow(textRenderer, Text.literal("YOUR PERMANENT PERK").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD), x + 12, y + 29, INK);
        c.drawTextWithShadow(textRenderer, Text.literal(selected.name + " — " + selected.rarity).formatted(Formatting.GOLD, Formatting.BOLD), x + 12, y + 45, INK);
        c.drawTextWithShadow(textRenderer, Text.literal(selected.buff), x + 12, y + 61, INK);
        c.drawTextWithShadow(textRenderer, Text.literal("AVAILABLE PERKS / ROLL CHANCES").formatted(Formatting.DARK_BLUE, Formatting.BOLD), x + half + 12, y + 29, INK);
        int row = 0;
        for (Perk p : PERKS) {
            c.drawTextWithShadow(textRenderer, Text.literal(p.name + " (" + p.rarity + ") " + p.chance + "%"), x + half + 12, y + 47 + row * 21, INK);
            row++;
        }
    }

    private void bar(DrawContext c, int x, int y, int w, String label, int value, int max, int color) {
        c.drawTextWithShadow(textRenderer, Text.literal(label + "  " + value + "/" + max), x, y, INK);
        int by = y + 11;
        c.fill(x, by, x + w, by + 7, 0xFF5A5148);
        int fill = (int)(w * Math.max(0, Math.min(1, value / (float)Math.max(1, max))));
        c.fill(x, by, x + fill, by + 7, color);
        c.fill(x, by, x + w, by + 1, 0x55FFFFFF);
    }

    private int number(String field, int fallback) {
        try { Class<?> c = Class.forName("com.realmforge.client.ClientRPGData"); Field f = c.getField(field); return f.getInt(null); }
        catch (Throwable ignored) { return fallback; }
    }
    private String string(String field, String fallback) {
        try { Object v = Class.forName("com.realmforge.client.ClientRPGData").getField(field).get(null); return v == null ? fallback : v.toString(); }
        catch (Throwable ignored) { return fallback; }
    }
    private int[] statValues() {
        try { Object a = Class.forName("com.realmforge.client.ClientRPGData").getField("stats").get(null); return (int[]) a; }
        catch (Throwable ignored) { return new int[7]; }
    }
    private String rankName(int level) {
        try {
            Class<?> rm = Class.forName("com.realmforge.progression.RankManager");
            Object rank = rm.getMethod("forLevel", int.class).invoke(null, level);
            return String.valueOf(rank.getClass().getField("displayName").get(rank));
        } catch (Throwable ignored) { return "Awakening"; }
    }
    private List<String> existingTraits() {
        List<String> out = new ArrayList<>();
        try {
            Class<?> registry = Class.forName("com.realmforge.registry.TraitRegistry");
            Object result = registry.getMethod("all").invoke(null);
            if (result instanceof Collection<?> all) {
                List<Object> entries = new ArrayList<>(all);
                double totalWeight = 0.0;
                for (Object trait : entries) {
                    Object rarity = trait.getClass().getMethod("rarity").invoke(trait);
                    try { totalWeight += rarity.getClass().getField("weight").getDouble(rarity); }
                    catch (Throwable ignoredWeight) { totalWeight += 1.0; }
                }
                for (Object trait : entries) {
                    String name = String.valueOf(trait.getClass().getMethod("name").invoke(trait));
                    Object rarity = trait.getClass().getMethod("rarity").invoke(trait);
                    String rarityName = String.valueOf(rarity);
                    double weight = 1.0;
                    try { weight = rarity.getClass().getField("weight").getDouble(rarity); }
                    catch (Throwable ignoredWeight) {}
                    String chance = String.format(Locale.ROOT, "%.1f%%", totalWeight <= 0 ? 0 : 100.0 * weight / totalWeight);
                    Object bonuses = trait.getClass().getMethod("bonuses").invoke(trait);
                    out.add(name + "|" + rarityName + "|" + chance + "|" + bonuses);
                }
            }
        } catch (Throwable ignored) { out.add("Trait registry|UNKNOWN|0%|Registry unavailable"); }
        return out;
    }
    private Perk selectedPerk() {
        UUID id = client != null && client.player != null ? client.player.getUuid() : new UUID(0, 0);
        long value = id.getMostSignificantBits() ^ id.getLeastSignificantBits();
        int roll = Math.floorMod((int)(value ^ (value >>> 32)), 100) + 1;
        int total = 0;
        for (Perk p : PERKS) { total += p.chance; if (roll <= total) return p; }
        return PERKS.get(0);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (page == Page.TRAITS) {
            listOffset = Math.max(0, listOffset + (verticalAmount < 0 ? 1 : -1));
            if (client != null) client.setScreen(new RealmForgeBookScreen(Page.TRAITS));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean shouldPause() { return false; }
}
