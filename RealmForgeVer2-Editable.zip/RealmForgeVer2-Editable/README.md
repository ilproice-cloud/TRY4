# RealmForgeVer2 — Fabric 1.21.1

This project layers a new two-page, opaque status book over the supplied RealmForge 0.1.0 JAR and builds a test JAR named `RealmForgeVer2-2.0.0.jar`.

## Included implementation

- Replaces the original stats book with a two-page book layout and removes the blur behind it.
- Shows player name, rank, HP/EXP/Energy bars with current/max values, level, points, and stats.
- Adds an Informations page.
- Adds separate Trait and Perk information pages reached from the status page's `Trait [?]` and `Perk [?]` buttons; those pages show a Back button.
- Reads the existing trait registry and displays trait names, rarities, and bonuses.
- Adds a permanent UUID-stable perk selection with rarity, bonus, and displayed selection chances.
- Sends stat-point requests to the existing RealmForge server payload.
- Initializes Energy to 3 for a level-1 player whose Energy is still zero; it does not overwrite existing progressed characters.
- No race or character-creation flow is added.

## Build on GitHub Actions

Upload this project folder to a repository, keeping `build.gradle`, `settings.gradle`, `libs/realmforge-0.1.0.jar`, and `src/` at the repository root. The workflow at `.github/workflows/build.yml` uses Java 21 and builds the mod. Download the `RealmForgeVer2` artifact from the workflow run.

## Testing status

This environment does not have Gradle installed and cannot run the Fabric build locally, so the build has **not been verified here**. Let GitHub Actions compile it; if it reports an error, share the complete log so the source can be corrected. Test in a backed-up world first.
