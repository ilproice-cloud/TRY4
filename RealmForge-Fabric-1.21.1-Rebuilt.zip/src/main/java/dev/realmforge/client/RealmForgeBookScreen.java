package dev.realmforge.client;

import dev.realmforge.RealmForge;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.Map;

/** Lightweight, responsive parchment character book. Pages 1-4 are the main book;
 * pages 5-6 are the Trait and Perk reference entries opened from page 4. */
public final class RealmForgeBookScreen extends Screen {
    private int page = 0;
    private int entry = 0;

    private static final List<String> TRAITS = List.of(
        "Battle Instinct", "Iron Will", "Arcane Soul", "Swift Current", "Vital Core",
        "Mana Conduit", "Predator's Focus", "Unbreakable", "Lucky Star", "Duelist's Edge");
    private static final List<String> PERKS = List.of(
        "Fast Learner", "Second Wind", "Energy Saver", "Heavy Hitter", "Fleet Footed",
        "Deep Reserves", "Guardian", "Keen Eye", "Overcharger", "Survivor");
    private static final String[] TRAIT_BUFFS = {
        "+2 melee bonus damage", "+5% chance to avoid incoming damage", "+15% energy-skill damage",
        "+0.015 movement speed and +8% dodge chance", "+4 maximum health",
        "+1 energy regeneration per second", "+2 melee damage against targets below 50% health",
        "+7% chance to avoid incoming damage", "+5% EXP from mob kills", "+1.5 melee bonus damage"
    };
    private static final String[] PERK_BUFFS = {
        "+20% EXP from mob kills", "Heals 5 HP at low health (cooldown)", "Energy skills cost 20% less",
        "+20% energy-skill damage and +2 melee damage", "+0.015 movement speed and +5% dodge chance",
        "+25 maximum energy and +2 maximum health", "+5% chance to avoid incoming damage",
        "+0.75 melee bonus damage", "+1 energy regeneration per second", "Heals 2 HP after a kill"
    };
    private static final String[] TRAIT_DEBUFFS = {
        "None", "None", "None", "None", "None", "None", "None", "None", "None", "None"
    };
    private static final String[] PERK_DEBUFFS = {
        "None", "None", "None", "None", "None", "None", "None", "None", "None", "None"
    };
    private static final String[] STAT_NAMES = {"STR", "AGI", "VIT", "INT", "ENE"};
    private static final String[] STAT_DESC = {
        "Adds +1 melee damage per point.",
        "Adds a small amount of movement speed and improves dodge chance.",
        "Adds +4 maximum HP per point.",
        "Increases skill damage and healing.",
        "Adds +5 maximum Energy per point and improves regeneration."
    };

    public RealmForgeBookScreen() { super(Text.literal("RealmForge Character Book")); }

    @Override protected void init() {
        int cx = width / 2;
        int bookW = Math.min(370, width - 12);
        int left = cx - bookW / 2;
        int bottom = height - 30;
        int navW = Math.max(54, Math.min(88, bookW / 3));
        addDrawableChild(ButtonWidget.builder(Text.literal("◀ Prev"), b -> {
            page = Math.max(0, page - 1); clearAndInit();
        }).dimensions(left + 5, bottom, navW, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Next ▶"), b -> {
            page = Math.min(5, page + 1); clearAndInit();
        }).dimensions(left + bookW - navW - 5, bottom, navW, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
            .dimensions(cx - 30, bottom, 60, 20).build());

        if (page == 1) {
            int bw = Math.max(43, Math.min(62, (bookW - 24) / 5));
            for (int i = 0; i < STAT_NAMES.length; i++) {
                String stat = STAT_NAMES[i];
                addDrawableChild(ButtonWidget.builder(Text.literal("+ " + stat),
                    b -> runCommand("realmforge add " + stat))
                    .dimensions(left + 8 + i * (bw + 2), bottom - 25, bw, 20).build());
            }
        }
        if (page == 3) {
            addDrawableChild(ButtonWidget.builder(Text.literal("TRAIT"), b -> { page = 4; entry = 0; clearAndInit(); })
                .dimensions(cx - 105, bottom - 26, 75, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("PERK"), b -> { page = 5; entry = 0; clearAndInit(); })
                .dimensions(cx - 25, bottom - 26, 75, 20).build());
        }
        if (page == 4 || page == 5) {
            addDrawableChild(ButtonWidget.builder(Text.literal("‹ Entry"), b -> { entry = Math.floorMod(entry - 1, 10); clearAndInit(); })
                .dimensions(cx - 88, bottom - 25, 76, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Entry ›"), b -> { entry = (entry + 1) % 10; clearAndInit(); })
                .dimensions(cx + 12, bottom - 25, 76, 20).build());
        }
    }

    private void runCommand(String command) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && client.getNetworkHandler() != null) client.getNetworkHandler().sendChatCommand(command);
    }

    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        renderBackground(c, mouseX, mouseY, delta);
        int cx = width / 2, bookW = Math.min(370, width - 12);
        int bookH = Math.min(286, height - 12), left = cx - bookW / 2, top = (height - bookH) / 2 - 5;
        c.fill(left - 4, top - 4, left + bookW + 4, top + bookH + 4, 0xff352116);
        c.fill(left, top, left + bookW, top + bookH, 0xffd8bd83);
        c.fill(left + 4, top + 4, left + bookW - 4, top + bookH - 4, 0xfff1dfb0);
        c.fill(cx - 1, top + 5, cx + 1, top + bookH - 5, 0xffa98a58);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("REALMFORGE"), cx, top + 9, 0xff542b18);
        String heading = switch (page) {
            case 0 -> "CHARACTER";
            case 1 -> "YOUR STATS";
            case 2 -> "STAT GUIDE";
            case 3 -> "INFORMATION";
            case 4 -> "TRAIT REFERENCE";
            default -> "PERK REFERENCE";
        };
        c.drawCenteredTextWithShadow(textRenderer, Text.literal(heading), cx, top + 23, 0xff6c371e);
        int y = top + 43;
        switch (page) {
            case 0 -> character(c, left, y);
            case 1 -> stats(c, left, y);
            case 2 -> statGuide(c, left, y);
            case 3 -> information(c, cx, y);
            case 4 -> reference(c, cx, y, true);
            case 5 -> reference(c, cx, y, false);
        }
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Page " + (page + 1) + " / 6"), cx, top + bookH - 17, 0xff6c371e);
        super.render(c, mouseX, mouseY, delta);
    }

    private RealmForge.SyncData data() { return RealmForgeClient.snapshot; }

    private void character(DrawContext c, int left, int y) {
        MinecraftClient mc = MinecraftClient.getInstance();
        RealmForge.SyncData d = data();
        String name = d != null && d.name != null ? d.name : mc.player == null ? "Loading..." : mc.player.getName().getString();
        line(c, "Player: " + name, left + 16, y, 0xff38251a);
        line(c, "Level: " + (d == null ? 1 : d.level), left + 16, y + 25, 0xff7b4c1e);
        line(c, "Rank: " + (d == null || d.rank == null ? "Novice" : d.rank), left + 16, y + 49, 0xff7b4c1e);
        line(c, "Trait: " + (d == null ? "Loading..." : d.trait), left + 16, y + 80, 0xffa14c2c);
        line(c, "Perk: " + (d == null ? "Loading..." : d.perk), left + 16, y + 105, 0xff6940a1);
        line(c, "Permanent selections — no rerolls", left + 16, y + 139, 0xff62513a);
        if (d != null) {
            line(c, "Stat points: " + d.points, left + 16, y + 163, 0xff38251a);
            line(c, "HP " + d.hp + "/" + d.hpMax + "   EXP " + d.xp + "/" + d.xpMax,
                left + 16, y + 184, 0xff38251a);
            line(c, "Energy " + d.energy + "/" + d.energyMax, left + 16, y + 205, 0xff245e99);
        }
    }

    private void stats(DrawContext c, int left, int y) {
        RealmForge.SyncData d = data();
        Map<String, Integer> s = d == null || d.stats == null ? Map.of() : d.stats;
        for (int i = 0; i < STAT_NAMES.length; i++) {
            String stat = STAT_NAMES[i];
            line(c, stat + "   " + s.getOrDefault(stat, 0), left + 18, y + i * 25, 0xff38251a);
        }
        line(c, "Available points: " + (d == null ? 0 : d.points), left + 18, y + 137, 0xff7b4c1e);
        line(c, "Use + buttons below to spend 1 point.", left + 18, y + 158, 0xff62513a);
    }

    private void statGuide(DrawContext c, int left, int y) {
        for (int i = 0; i < STAT_NAMES.length; i++) {
            line(c, STAT_NAMES[i] + ": " + STAT_DESC[i], left + 12, y + i * 30, 0xff38251a);
        }
        line(c, "Level up: +3 stat points.", left + 12, y + 165, 0xff27864c);
        line(c, "Mob defeats grant EXP.", left + 12, y + 185, 0xff27864c);
    }

    private void information(DrawContext c, int cx, int y) {
        String[] lines = {
            "Browse every Trait and Perk in the archive.",
            "Each player receives one of each on first join.",
            "Selections are saved and cannot be rerolled.",
            "All 10 Traits have equal selection chance.",
            "All 10 Perks have equal selection chance.",
            "Selection chance per entry: 10%",
            "",
            "Open a reference page with the buttons below."
        };
        for (int i = 0; i < lines.length; i++)
            c.drawCenteredTextWithShadow(textRenderer, Text.literal(lines[i]), cx, y + i * 17, 0xff38251a);
    }

    private void reference(DrawContext c, int cx, int y, boolean trait) {
        List<String> names = trait ? TRAITS : PERKS;
        String[] buffs = trait ? TRAIT_BUFFS : PERK_BUFFS;
        String[] debuffs = trait ? TRAIT_DEBUFFS : PERK_DEBUFFS;
        String name = names.get(entry);
        Formatting rarity = rarity(entry);
        int color = rarity.getColorValue() == null ? 0xff38251a : 0xff000000 | rarity.getColorValue();
        c.drawCenteredTextWithShadow(textRenderer, Text.literal(name), cx, y + 4, color);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Rarity: " + rarity.getName()), cx, y + 25, color);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Actual selection chance: 10%"), cx, y + 45, 0xff38251a);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("BUFF"), cx, y + 70, 0xff20843c);
        drawWrapped(c, buffs[entry], cx, y + 84, Math.min(320, width - 38), 0xff20843c);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("DEBUFF"), cx, y + 125, 0xffc12c2c);
        drawWrapped(c, debuffs[entry], cx, y + 139, Math.min(320, width - 38), 0xffc12c2c);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal((entry + 1) + " / 10"), cx, y + 181, 0xff62513a);
    }

    private Formatting rarity(int index) {
        return switch (index % 5) {
            case 0 -> Formatting.GOLD;
            case 1 -> Formatting.LIGHT_PURPLE;
            case 2 -> Formatting.BLUE;
            case 3 -> Formatting.GREEN;
            default -> Formatting.GRAY;
        };
    }

    private void drawWrapped(DrawContext c, String text, int cx, int y, int maxWidth, int color) {
        StringBuilder row = new StringBuilder();
        int rowY = y;
        for (String word : text.split(" ")) {
            String candidate = row.length() == 0 ? word : row + " " + word;
            if (textRenderer.getWidth(candidate) > maxWidth && row.length() > 0) {
                c.drawCenteredTextWithShadow(textRenderer, Text.literal(row.toString()), cx, rowY, color);
                rowY += 12; row.setLength(0); row.append(word);
            } else {
                if (row.length() > 0) row.append(' ');
                row.append(word);
            }
        }
        if (row.length() > 0) c.drawCenteredTextWithShadow(textRenderer, Text.literal(row.toString()), cx, rowY, color);
    }

    private void line(DrawContext c, String text, int x, int y, int color) {
        c.drawTextWithShadow(textRenderer, Text.literal(text), x, y, color);
    }

    @Override public boolean shouldPause() { return false; }
}
