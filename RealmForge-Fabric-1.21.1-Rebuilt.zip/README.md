# RealmForge — Fabric 1.21.1

A from-scratch RPG progression mod for Minecraft Java 1.21.1 / Fabric. Java 21 required.

## Build on GitHub (works from a phone)
1. Upload this entire project to a GitHub repository (keep the `.github/workflows/build.yml` path).
2. Open **Actions → Build RealmForge → Run workflow**.
3. When the workflow finishes, open its run and download the `RealmForge-Fabric-1.21.1` artifact.
4. Put the resulting `RealmForge-0.1.0.jar` in the Fabric 1.21.1 `mods` folder together with Fabric API.
5. Launch that Fabric profile in PojavLauncher.

## Controls
- **K**: open the paged RealmForge book.
- **Z / X / C / V / B / N**: cast skill slots 1–6.

## Commands
- `/realmforge stats` — character stats, rank, resources, Trait and Perk.
- `/realmforge add <STR|AGI|VIT|INT|ENE>` — spend a stat point.
- `/realmforge skill <burst|focus|dash|nova|heal|guard>` — cast a skill.
- `/realmforge slot <1-6> <skill>` — configure a skill slot.
- `/realmforge cast <1-6>` — cast a configured slot.
- `/realmforge equipment` — list equipment slots.
- `/realmforge equip <pant|shirt|hat|shoes|weapon> <item>` — set an equipment record; use item words such as `iron_sword`, `diamond_boots`, `legendary_blade`, or `mythic_armor` to apply the built-in gear bonus rules.
- `/realmforge mastery` — inspect skill mastery.
- `/realmforge info` — help.

## Implemented systems
- STR, AGI, VIT, INT and ENE; stat points and level/EXP progression.
- Server-side player data saved in `realmforge-playerdata.json` in the world save root.
- One randomly selected Trait and one Perk per player; selections are persisted and there is no reroll command.
- Trait/Perk combat, health, movement, dodge, energy and EXP effects.
- Paged parchment character book, Trait/Perk archive, skill page, equipment page, mastery page, and HP/EXP/Energy HUD.
- Six skill slots and six skills, with keyboard bindings.
- Rank progression, equipment records and skill mastery (maximum level 300).
- GitHub Actions build workflow.

## Notes
This is a new implementation, not a port of an older RealmForge source. It has not been verified in a running Minecraft client in this environment. The GitHub Actions build is the first required compilation check; after it succeeds, test on a copied world in PojavLauncher. Equipment is a lightweight RPG equipment-record system, not a replacement for vanilla inventory armor slots.


## Scope and verification honesty
The uploaded input for this rebuild was a ZIP containing a source project, not the original mod JAR plus a separate source JAR. Therefore, this rebuild preserves the systems found in that supplied project; I could not compare against any additional features that may exist only in a different JAR. The supplied project has no race data, race commands, or race mechanics, so no race system was available to preserve or verify.

The character book is organized as:
1. Character — actual player name, rank, level, Trait, Perk and resource summaries.
2. Stats — STR, AGI, VIT, INT and ENE with stat-point buttons.
3. Stat Guide — what each stat changes.
4. Information — TRAIT and PERK buttons.
5. Trait reference — entries with rarity color, 10% selection chance, buff and debuff field.
6. Perk reference — entries with rarity color, 10% selection chance, buff and debuff field.

Trait and Perk chances are 10% each because the server selects uniformly from 10 entries. Rarity is a separate display classification and does not alter selection chance. The original effects currently define no debuffs, so the reference pages explicitly show "None" rather than inventing unimplemented penalties.

**Build status:** Not compiled or launched in this environment because Gradle is not installed and no Gradle wrapper is included. The included GitHub Actions workflow installs Gradle 8.10.2 and Java 21 and runs `gradle clean build`; use the Actions result as the first compilation check. Runtime behavior, multiplayer behavior, and PojavLauncher compatibility still need in-game testing.
