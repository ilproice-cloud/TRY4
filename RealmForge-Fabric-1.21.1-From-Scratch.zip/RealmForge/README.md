# RealmForge — Fabric 1.21.1

A from-scratch RPG progression mod for Minecraft Java 1.21.1 / Fabric. Java 21 required.

## Build on GitHub (works from a phone)
1. Upload this entire project to a GitHub repository (keep the `.github/workflows/build.yml` path).
2. Open **Actions → Build RealmForge → Run workflow**.
3. When the workflow finishes, open its run and download the `RealmForge-Fabric-1.21.1` artifact.
4. Put the resulting `RealmForge-0.1.0.jar` in the Fabric 1.21.1 `mods` folder together with Fabric API.
5. Launch that Fabric profile in PojavLauncher.

## Controls
- **K**: open the paged RealmForge book.
- **Z / X / C / V / B / N**: cast skill slots 1–6.

## Commands
- `/realmforge stats` — character stats, rank, resources, Trait and Perk.
- `/realmforge add <STR|AGI|VIT|INT|ENE>` — spend a stat point.
- `/realmforge skill <burst|focus|dash|nova|heal|guard>` — cast a skill.
- `/realmforge slot <1-6> <skill>` — configure a skill slot.
- `/realmforge cast <1-6>` — cast a configured slot.
- `/realmforge equipment` — list equipment slots.
- `/realmforge equip <pant|shirt|hat|shoes|weapon> <item>` — set an equipment record; use item words such as `iron_sword`, `diamond_boots`, `legendary_blade`, or `mythic_armor` to apply the built-in gear bonus rules.
- `/realmforge mastery` — inspect skill mastery.
- `/realmforge info` — help.

## Implemented systems
- STR, AGI, VIT, INT and ENE; stat points and level/EXP progression.
- Server-side player data saved in `realmforge-playerdata.json` in the world save root.
- One randomly selected Trait and one Perk per player; selections are persisted and there is no reroll command.
- Trait/Perk combat, health, movement, dodge, energy and EXP effects.
- Paged parchment character book, Trait/Perk archive, skill page, equipment page, mastery page, and HP/EXP/Energy HUD.
- Six skill slots and six skills, with keyboard bindings.
- Rank progression, equipment records and skill mastery (maximum level 300).
- GitHub Actions build workflow.

## Notes
This is a new implementation, not a port of an older RealmForge source. It has not been verified in a running Minecraft client in this environment. The GitHub Actions build is the first required compilation check; after it succeeds, test on a copied world in PojavLauncher. Equipment is a lightweight RPG equipment-record system, not a replacement for vanilla inventory armor slots.
