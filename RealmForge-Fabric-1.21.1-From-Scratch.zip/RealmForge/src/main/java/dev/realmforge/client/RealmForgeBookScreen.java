package dev.realmforge.client;

import dev.realmforge.RealmForge;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.util.List;
import java.util.Map;

/** Compact vanilla-styled parchment book with real page navigation and command-backed actions. */
public final class RealmForgeBookScreen extends Screen {
    private int page = 0;
    private int referenceIndex = 0;
    private static final List<String> TRAITS = List.of("Battle Instinct", "Iron Will", "Arcane Soul", "Swift Current", "Vital Core", "Mana Conduit", "Predator's Focus", "Unbreakable", "Lucky Star", "Duelist's Edge");
    private static final List<String> PERKS = List.of("Fast Learner", "Second Wind", "Energy Saver", "Heavy Hitter", "Fleet Footed", "Deep Reserves", "Guardian", "Keen Eye", "Overcharger", "Survivor");
    private static final String[] TRAIT_INFO = {
        "+2 melee bonus damage.", "Gain a defensive dodge chance.", "+15% energy skill damage.", "Higher movement speed and dodge chance.", "+4 maximum health.", "+1 energy regeneration each second.", "Bonus melee damage against weakened targets.", "Extra chance to avoid incoming hits.", "+5% EXP from mob kills.", "+1.5 melee bonus damage."
    };
    private static final String[] PERK_INFO = {
        "+20% EXP from mob kills.", "Automatically recover health at low HP.", "Energy skill costs are reduced by 20%.", "+20% energy skill damage.", "Higher movement speed and dodge chance.", "+25 maximum energy.", "Extra chance to avoid incoming hits.", "Improves attack consistency (small bonus damage).", "+1 energy regeneration each second.", "Recover a little health after a kill."
    };

    public RealmForgeBookScreen() { super(Text.literal("RealmForge Character Book")); }
    @Override protected void init() {
        int cx = width / 2, bookW = Math.min(370, width - 12), left = cx - bookW / 2;
        int bottom = Math.min(height - 26, height / 2 + Math.min(112, height / 3));
        int navW = Math.max(62, Math.min(95, bookW / 3));
        addDrawableChild(ButtonWidget.builder(Text.literal("◀ Prev"), b -> { page = Math.max(0, page - 1); clearAndInit(); }).dimensions(left + 5, bottom, navW, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Next ▶"), b -> { page = Math.min(6, page + 1); clearAndInit(); }).dimensions(left + bookW - navW - 5, bottom, navW, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close()).dimensions(cx - 32, bottom + 22, 64, 20).build());
        if (page == 0) {
            String[] stats = {"STR", "AGI", "VIT", "INT", "ENE"};
            int usable = bookW - 18, bw = Math.max(42, usable / 5 - 2), start = left + 9;
            for (int i = 0; i < stats.length; i++) { String s = stats[i]; addDrawableChild(ButtonWidget.builder(Text.literal("+" + s), b -> runCommand("realmforge add " + s)).dimensions(start + i * (bw + 2), bottom - 24, bw, 20).build()); }
        }
        if (page == 1) {
            addDrawableChild(ButtonWidget.builder(Text.literal("TRAIT"), b -> { page = 2; referenceIndex = 0; clearAndInit(); }).dimensions(cx - 105, bottom - 25, 75, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("PERK"), b -> { page = 3; referenceIndex = 0; clearAndInit(); }).dimensions(cx - 25, bottom - 25, 75, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("? Help"), b -> runCommand("realmforge info")).dimensions(cx + 55, bottom - 25, 52, 20).build());
        }
        if (page == 2 || page == 3) {
            addDrawableChild(ButtonWidget.builder(Text.literal("‹"), b -> { referenceIndex = Math.floorMod(referenceIndex - 1, 10); clearAndInit(); }).dimensions(cx - 75, bottom - 24, 30, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("›"), b -> { referenceIndex = (referenceIndex + 1) % 10; clearAndInit(); }).dimensions(cx + 45, bottom - 24, 30, 20).build());
        }
        if (page == 4) {
            String[] keys = {"Z", "X", "C", "V", "B", "N"};
            for (int i = 0; i < 6; i++) { final int slot = i + 1; addDrawableChild(ButtonWidget.builder(Text.literal(keys[i] + " · Cast " + slot), b -> runCommand("realmforge cast " + slot)).dimensions(cx - 100 + (i % 2) * 105, bottom - 68 + (i / 2) * 21, 100, 19).build()); }
        }
        if (page == 5) addDrawableChild(ButtonWidget.builder(Text.literal("View equipment"), b -> runCommand("realmforge equipment")).dimensions(cx - 58, bottom - 24, 116, 20).build());
        if (page == 6) addDrawableChild(ButtonWidget.builder(Text.literal("Refresh mastery"), b -> runCommand("realmforge mastery")).dimensions(cx - 58, bottom - 24, 116, 20).build());
    }

    private void runCommand(String command) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && client.getNetworkHandler() != null) client.getNetworkHandler().sendChatCommand(command);
    }

    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        renderBackground(c, mouseX, mouseY, delta);
        int cx = width / 2, bookW = Math.min(370, width - 12), bookH = Math.min(286, height - 12), left = cx - bookW / 2, top = (height - bookH) / 2 - 5;
        c.fill(left - 4, top - 4, left + bookW + 4, top + bookH + 4, 0xff352116);
        c.fill(left, top, left + bookW, top + bookH, 0xffd8bd83);
        c.fill(left + 4, top + 4, left + bookW - 4, top + bookH - 4, 0xfff1dfb0);
        c.fill(cx - 1, top + 5, cx + 1, top + bookH - 5, 0xffa98a58);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("REALMFORGE"), cx, top + 10, 0xff542b18);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal(switch (page) { case 0 -> "CHARACTER RECORD"; case 1 -> "INFORMATION"; case 2 -> "TRAIT ARCHIVE"; case 3 -> "PERK ARCHIVE"; case 4 -> "SKILL GRIMOIRE"; case 5 -> "EQUIPMENT"; default -> "SKILL MASTERY"; }), cx, top + 25, 0xff6c371e);
        int y = top + 44;
        switch (page) { case 0 -> character(c, left, y, cx); case 1 -> information(c, y, cx); case 2 -> reference(c, y, cx, true); case 3 -> reference(c, y, cx, false); case 4 -> skills(c, y, cx); case 5 -> equipment(c, y, cx); default -> mastery(c, y, cx); }
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Page " + (page + 1) + " / 7"), cx, top + bookH - 17, 0xff6c371e);
        super.render(c, mouseX, mouseY, delta);
    }

    private void character(DrawContext c, int left, int y, int cx) {
        MinecraftClient mc = MinecraftClient.getInstance(); RealmForge.SyncData d = RealmForgeClient.snapshot;
        String name = d != null ? d.name : mc.player == null ? "Unknown" : mc.player.getName().getString();
        int hp = d != null ? d.hp : mc.player == null ? 0 : (int)mc.player.getHealth(), maxHp = d != null ? d.hpMax : mc.player == null ? 20 : (int)mc.player.getMaxHealth();
        int level = d == null ? 1 : d.level, xp = d == null ? 0 : d.xp, xpMax = d == null ? 100 : d.xpMax, energy = d == null ? 3 : d.energy, energyMax = d == null ? 3 : d.energyMax;
        c.drawTextWithShadow(textRenderer, Text.literal("Name: " + name), left + 13, y, 0xff38251a);
        c.drawTextWithShadow(textRenderer, Text.literal("Level " + level + "  ·  Rank " + (d == null ? "Novice" : d.rank)), left + 13, y + 14, 0xff38251a);
        drawBar(c, left + 13, y + 34, 130, 8, hp, maxHp, 0xffbd3333); c.drawTextWithShadow(textRenderer, Text.literal("HP " + hp + "/" + maxHp), left + 150, y + 33, 0xff38251a);
        drawBar(c, left + 13, y + 49, 130, 8, xp, xpMax, 0xff319e45); c.drawTextWithShadow(textRenderer, Text.literal("EXP " + xp + "/" + xpMax), left + 150, y + 48, 0xff38251a);
        drawBar(c, left + 13, y + 64, 130, 8, energy, energyMax, 0xff347fce); c.drawTextWithShadow(textRenderer, Text.literal("ENE " + energy + "/" + energyMax), left + 150, y + 63, 0xff38251a);
        Map<String, Integer> s = d == null || d.stats == null ? Map.of() : d.stats;
        c.drawTextWithShadow(textRenderer, Text.literal("STR  " + s.getOrDefault("STR", 0) + "       AGI  " + s.getOrDefault("AGI", 0)), left + 13, y + 84, 0xff38251a);
        c.drawTextWithShadow(textRenderer, Text.literal("VIT  " + s.getOrDefault("VIT", 0) + "       INT  " + s.getOrDefault("INT", 0)), left + 13, y + 100, 0xff38251a);
        c.drawTextWithShadow(textRenderer, Text.literal("ENE  " + s.getOrDefault("ENE", 0) + "       Stat points  " + (d == null ? 0 : d.points)), left + 13, y + 116, 0xff38251a);
        c.drawTextWithShadow(textRenderer, Text.literal("Trait: " + (d == null ? "Loading..." : d.trait)), left + 13, y + 136, 0xffa14c2c);
        c.drawTextWithShadow(textRenderer, Text.literal("Perk: " + (d == null ? "Loading..." : d.perk)), left + 13, y + 151, 0xff6940a1);
    }

    private void information(DrawContext c, int y, int cx) {
        String[] lines = {"Your character gets one permanent Trait", "and one permanent Perk on first join.", "They are saved with your world player data.", "", "STR: melee bonus damage", "AGI: movement speed and dodge chance", "VIT: maximum health", "INT: skill power", "ENE: maximum energy and regeneration", "", "Mob kills grant EXP; each level grants 3 points.", "Use the buttons below to browse Trait / Perk."};
        for (int i = 0; i < lines.length; i++) c.drawCenteredTextWithShadow(textRenderer, Text.literal(lines[i]), cx, y + i * 12, 0xff38251a);
    }

    private void reference(DrawContext c, int y, int cx, boolean trait) {
        List<String> list = trait ? TRAITS : PERKS; String name = list.get(referenceIndex);
        int color = referenceIndex % 5 == 0 ? 0xffb52e2e : referenceIndex % 5 == 1 ? 0xffa34cc4 : referenceIndex % 5 == 2 ? 0xff3976c7 : referenceIndex % 5 == 3 ? 0xff27864c : 0xff8b6a2a;
        String[] desc = trait ? TRAIT_INFO : PERK_INFO;
        c.drawCenteredTextWithShadow(textRenderer, Text.literal(name), cx, y + 4, color);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Entry " + (referenceIndex + 1) + " of 10 · Chance 10%"), cx, y + 24, 0xff38251a);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Rarity: " + (referenceIndex % 5 == 0 ? "Legendary" : referenceIndex % 5 == 1 ? "Epic" : referenceIndex % 5 == 2 ? "Rare" : referenceIndex % 5 == 3 ? "Uncommon" : "Common")), cx, y + 43, color);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal(desc[referenceIndex]), cx, y + 67, 0xff27864c);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Permanent after selection; cannot reroll."), cx, y + 88, 0xffa32d2d);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Browse with ‹ and › below."), cx, y + 108, 0xff38251a);
    }

    private void skills(DrawContext c, int y, int cx) {
        RealmForge.SyncData d = RealmForgeClient.snapshot;
        String[] keys = {"Z", "X", "C", "V", "B", "N"};
        for (int i = 0; i < 6; i++) {
            String skill = d != null && d.slots != null && d.slots.size() > i ? d.slots.get(i) : new String[]{"burst", "focus", "dash", "nova", "heal", "guard"}[i];
            c.drawCenteredTextWithShadow(textRenderer, Text.literal(keys[i] + "  ·  Slot " + (i + 1) + "  ·  " + skill.toUpperCase()), cx, y + 8 + i * 17, 0xff38251a);
        }
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Edit: /realmforge slot <1-6> <skill>"), cx, y + 120, 0xff6c371e);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Skills: burst, focus, dash, nova, heal, guard"), cx, y + 136, 0xff6c371e);
    }

    private void equipment(DrawContext c, int y, int cx) {
        RealmForge.SyncData d = RealmForgeClient.snapshot;
        String[] slots = {"pant", "shirt", "hat", "shoes", "weapon"};
        for (int i = 0; i < slots.length; i++) {
            String slot = slots[i]; String item = d == null || d.equipment == null ? "None" : d.equipment.getOrDefault(slot, "None");
            c.drawCenteredTextWithShadow(textRenderer, Text.literal(slot.toUpperCase() + ":  " + item), cx, y + 8 + i * 20, 0xff38251a);
        }
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Set: /realmforge equip <slot> <item>"), cx, y + 119, 0xff6c371e);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Slots: pant, shirt, hat, shoes, weapon"), cx, y + 135, 0xff6c371e);
    }

    private void mastery(DrawContext c, int y, int cx) {
        RealmForge.SyncData d = RealmForgeClient.snapshot;
        String[] skills = {"burst", "focus", "dash", "nova", "heal", "guard"};
        for (int i = 0; i < skills.length; i++) {
            String skill = skills[i]; int level = d == null || d.mastery == null ? 0 : d.mastery.getOrDefault(skill, 0);
            int masteryXp = d == null || d.masteryXp == null ? 0 : d.masteryXp.getOrDefault(skill, 0);
            c.drawCenteredTextWithShadow(textRenderer, Text.literal(skill.toUpperCase() + "  ·  Mastery " + level + "/300  ·  " + masteryXp + "/2000 EXP"), cx, y + 5 + i * 16, 0xff38251a);
        }
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("50 mastery EXP per skill use · 2000 per level"), cx, y + 107, 0xff6c371e);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Skill damage increases 2.5% per mastery level"), cx, y + 123, 0xff27864c);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("Use /realmforge mastery for exact EXP values"), cx, y + 139, 0xff6c371e);
    }

    private void drawBar(DrawContext c, int x, int y, int w, int h, int value, int max, int color) {
        c.fill(x, y, x + w, y + h, 0xff806b4c);
        int fill = (int)(w * Math.max(0, Math.min(1, value / (double)Math.max(1, max))));
        if (fill > 0) c.fill(x + 1, y + 1, x + fill, y + h - 1, color);
    }
    @Override public boolean shouldPause() { return false; }
}
